        <title>Vapronix Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

<div class="container bootstrap snippet">
<div class="panel-body inf-content informationPanel" hidden>
    <div class="row">
        <div class="col-md-4">
            <img alt="" style="width:600px;" title="" class="img-circle img-thumbnail isTooltip" src="http://bootdey.com/img/Content/user-453533-fdadfd.png" data-original-title="Usuario" id="profilePic"> 
            <ul title="Ratings" class="list-inline ratings text-center">
                <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
            </ul>
        </div>
        <div class="col-md-6">
            <strong>Facebook User Information</strong><br>
            <div class="table-responsive">
            <table class="table table-condensed table-responsive table-user-information">
                <tbody>
                    <tr>        
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-asterisk text-primary"></span>
                                Identificacion                                                
                            </strong>
                        </td>
                        <td class="text-primary" id="facebookId">
                                
                        </td>
                    </tr>
                    <tr>    
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-user  text-primary"></span>    
                                First Name                                                
                            </strong>
                        </td>
                        <td class="text-primary" id="first_name">
                        </td>
                    </tr>
                    <tr>    
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-user  text-primary"></span>    
                                Last Name                                
                            </strong>
                        </td>
                        <td class="text-primary" id="last_name">
                        </td>
                    </tr>
                    <tr>    
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-user  text-primary"></span>    
                                Name                                                
                            </strong>
                        </td>
                        <td class="text-primary" id="name">
                        </td>
                    </tr>

                    <tr>        
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-cloud text-primary"></span>  
                                Birthday                             
                            </strong>
                        </td>
                        <td class="text-primary" id="birthday">     
                        </td>
                    </tr>
                    <tr>        
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-bookmark text-primary"></span> 
                                Email                                                
                            </strong>
                        </td>
                        <td class="text-primary" id="email">
                        </td>
                    </tr>
                    <tr>        
                        <td>
                            <strong>
                                <span class="glyphicon glyphicon-bookmark text-primary"></span> 
                                Gender                                                
                            </strong>
                        </td>
                        <td class="text-primary" id="gender">
                        </td>
                    </tr>                                  
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<div class="facebookLoginButton">
    <input type="button" name="button" value="button" hidden>
     <fb:login-button scope="public_profile,email" onlogin="checkLoginState();" size="xlarge" auto-logout-link="true">Connect with Facebook</fb:login-button>     
</div>
</div>

<style type="text/css">
    .facebookLoginButton {
    position:relative;
    left: 41%;
    margin-top:26%;
        width: 50%;
    }
    .inf-content{
    border:1px solid #DDDDDD;
    -webkit-border-radius:10px;
    -moz-border-radius:10px;
    border-radius:10px;
    box-shadow: 7px 7px 7px rgba(0, 0, 0, 0.3);
    }
    .informationPanel{
        margin-top: 20%;
    }    
</style>
<script src="js/index.js"></script>                                                                
</style>